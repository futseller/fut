Fut is written and maintained by Piotr Staroszczyk and various contributors:

Development Lead
````````````````

- Piotr Staroszczyk <piotr.staroszczyk@get24.org>


Documentation mainteiner
------------------------

- Trevor McCormick @TrevorMcCormick


EAHashingAlgorithm
``````````````````

- Danny Cullen @dcullen88


Patches and Suggestions
```````````````````````
- mvillarejo
- Mauro Marano
- Innursery
- Arthur Nogueira Neves @arthurnn
- jamslater
- rjansen
- ricklhp7
- hunterjm
- fifa2017player
- bas85
- spacedlevo
- pulkitsharma
- xAranaktu
- LasseRegin
- kirov
- jsarasti
- Trevor McCormick @TrevorMcCormick
- derSoerrn95
- TheYellowKrato
- kmiloflorez2
