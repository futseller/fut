================================================================================================================================================
FUT21 Api: Login, Relist, keepalive successfully updated.  Market Test Next
================================================================================================================================================

===
fut21
===

fut is a simple library for managing Fifa Ultimate Team.
It is written entirely in Python.

`Click here to get Slack invitation <https://gentle-everglades-93932.herokuapp.com>`_



Documentation
=============

Documentation is available at http://fut.readthedocs.org/.

Forked From DomMonte/FUT



