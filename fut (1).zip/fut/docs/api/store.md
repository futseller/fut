## Store
Below is the current state of functionality within the **Store** category.

Two methods exist in the Store category

<img src="https://i.imgur.com/0ZIHL3q.png" alt="Store" style="height: 100px;"/>

---

### fut.buyPack()

fut.buyPack() takes two arguments: `pack_id` and `currency` (default: 'COINS'). We're still working on a list of pack_ids.
Until then, this function is lacking documentation.  

### fut.openPack()

fut.openPack() takes one arguemtn: `pack_id`. We're still working on a list of pack_ids. Until then, this function is lacking documentation.  
