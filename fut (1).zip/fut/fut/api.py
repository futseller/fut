# -*- coding: utf-8 -*-

"""
fut.api
~~~~~~~~~~~~~~~~~~~~~

This module implements the fut's API.

"""

from .core import baseId, cardInfo


pass
