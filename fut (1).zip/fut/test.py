import fut

session = fut.Core(
    email="YOUR_EMAIL", 
    passwd="PASSWORD", 
    platform="xbox", 
    code="___",
    secret_answer="___",
    cookies=False
)

print(session)